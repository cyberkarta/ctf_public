<?php

$p = "hello everyone, my name is wrops, my strength is within myself";
$encoded = base64_encode($p);
echo $encoded;
// part2 = lf1_1s_

?>