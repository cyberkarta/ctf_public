<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>kartamovie</title>
  </head>
  <body>
    <h1>CINEMA CYBERKARTA</h1>
    <h2>HACKERMAN SERIES</h2>
    
    <img src="poster/hackerman.jpeg" width="200" lenght="200">
    <hr/>
    
    <a href="index.php">Home</a> |
    <a href="index.php?part=episode1.php">Episode 1</a> |
    <a href="index.php?part=episode2.php">Episode 2</a> |
    <a href="index.php?part=episode3.php">Episode 3 (end)</a> |

    <?php 
    
    if (isset($_GET['part'])) 
    {   
        include $_GET['part']; 
    } 
    else 
    {
        // part3 = d4ng3r0us}
        echo "<p>TAMATKAN 3 Episode untuk menjadi seorang HEKEL</p>";
    }
    
    ?>
    
  </body>
</html>