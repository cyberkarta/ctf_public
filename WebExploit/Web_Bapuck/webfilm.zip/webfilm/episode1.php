<p> 
    Find Me in /usr/seriesname
</p>