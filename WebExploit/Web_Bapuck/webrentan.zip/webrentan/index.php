<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>lab cyberkarta</title>
  </head>
  <body>
    <h1>Web BAPUCK</h1>
    <a href="index.php">Home</a> |
    <a href="index.php?page=page1.php">Page 1</a> |
    <a href="index.php?page=page2.php">Page 2</a> |
    <a href="index.php?page=page3.php">Page 3</a>
    
    <hr/>
    
    <?php 
    
    if (isset($_GET['page'])) 
    {   
        include $_GET['page']; 
    } 
    else 
    {
        echo "<p>Penasaran sama yang lain, silahkan di unboxing.</p>";
    }
    
    ?>
    
  </body>
</html>


